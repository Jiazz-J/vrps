package com.virtusa.vrps.models;

public class Employee {

	private String employeeId;
	private EducationDetails educationDetails;
	private PersonalDetails personalDetails;
	private WorkDetails workDetails;
	private Projects projects;
	private String referenceId;

	public Projects getProjects() {
		return projects;
	}

	public void setProjects(Projects projects) {
		this.projects = projects;
	}

	public Employee(String employeeId, EducationDetails educationDetails, PersonalDetails personalDetails,
			WorkDetails workDetails, Projects projects, String referenceId) {
		super();
		this.employeeId = employeeId;
		this.educationDetails = educationDetails;
		this.personalDetails = personalDetails;
		this.workDetails = workDetails;
		this.projects = projects;
		this.referenceId = referenceId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public EducationDetails getEducationDetails() {
		return educationDetails;
	}

	public void setEducationDetails(EducationDetails educationDetails) {
		this.educationDetails = educationDetails;
	}

	public PersonalDetails getPersonalDetails() {
		return personalDetails;
	}

	public void setPersonalDetails(PersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}

	public WorkDetails getWorkDetails() {
		return workDetails;
	}

	public void setWorkDetails(WorkDetails workDetails) {
		this.workDetails = workDetails;
	}
}
