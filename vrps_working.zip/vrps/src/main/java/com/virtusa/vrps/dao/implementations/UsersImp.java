package com.virtusa.vrps.dao.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.vrps.dao.interfaces.UsersDao;
import com.virtusa.vrps.helpers.OracleHelper;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Users;

public class UsersImp implements UsersDao {

	private ResourceBundle rb;
	private Connection conn;
	private Statement statement;
	private ResultSet resultSet;
	private Users users;

	@Override
	public List<Users> getAllUsers() throws SQLException {
		// TODO Auto-generated method stub

		List<Users> userList = new ArrayList<Users>();
		rb = ResourceBundle.getBundle("com.virtusa.vrps.resources.db");
		String getUsersQuery = rb.getString("getUsersQuery");

		conn = OracleHelper.getConnection();
		statement = conn.createStatement();
		resultSet = statement.executeQuery(getUsersQuery);
		// users = new Users();
		while (resultSet.next()) {
			users = new Users();
			users.setUserId(resultSet.getString(1));
			users.setUserPassword(resultSet.getString(2));
			users.setDesignation(resultSet.getString(3));

			userList.add(users);

		}
		conn.close();

		return userList;
	}

	@Override
	public boolean setCreateProfile(Employee employee) throws SQLException {
		// TODO Auto-generated method stub

		conn = OracleHelper.getConnection();

		boolean status = false;

		conn.setAutoCommit(false);
		CallableStatement callableStatement = conn.prepareCall("{call personaldetails_proc(?,?,?,?,?,?,?)}");
		callableStatement.setString(1, employee.getEmployeeId());
		callableStatement.setString(2, employee.getPersonalDetails().getFullName());
		callableStatement.setDate(3, new java.sql.Date(employee.getPersonalDetails().getDob().getTime()));
		callableStatement.setString(4, employee.getPersonalDetails().getGender());
		callableStatement.setLong(5, employee.getPersonalDetails().getMobile());
		callableStatement.setString(6, employee.getPersonalDetails().getEmail());
		callableStatement.setString(7, employee.getPersonalDetails().getAddress());
		int result1 = callableStatement.executeUpdate();

		CallableStatement callableStatement2 = conn.prepareCall("{call workdetails_proc(?,?,?,?,?,?,?,?)}");
		callableStatement2.setString(1, employee.getEmployeeId());
		callableStatement2.setString(2, employee.getWorkDetails().getDesignation());
		callableStatement2.setInt(3, employee.getWorkDetails().getCtc());
		callableStatement2.setString(4, employee.getWorkDetails().getCurrentLocation());
		callableStatement2.setString(5, employee.getWorkDetails().getRequiredLocation());
		callableStatement2.setInt(6, employee.getWorkDetails().getExperience());
		callableStatement2.setString(7, employee.getWorkDetails().getAppliedjob());
		callableStatement2.setString(8, employee.getWorkDetails().getSkills());
		int result2 = callableStatement2.executeUpdate();

		CallableStatement callableStatement3 = conn.prepareCall("{ call projects_proc(?,?,?,?,?) }");
		callableStatement3.setString(1, employee.getEmployeeId());
		callableStatement3.setString(2, employee.getProjects().getTitle());
		callableStatement3.setDate(3, new java.sql.Date(employee.getProjects().getStartdate().getTime()));
		callableStatement3.setDate(4, new java.sql.Date(employee.getProjects().getEnddate().getTime()));
		callableStatement3.setString(5, employee.getProjects().getDescription());
		int result3 = callableStatement3.executeUpdate();

		CallableStatement callableStatement4 = conn
				.prepareCall("{ call educationdetails_proc(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
		callableStatement4.setString(1, employee.getEmployeeId());
		callableStatement4.setString(2, employee.getEducationDetails().getSchoolName());
		callableStatement4.setInt(3, employee.getEducationDetails().getSchoolPercent());
		callableStatement4.setInt(4, employee.getEducationDetails().getSchoolPassYear());
		callableStatement4.setString(5, employee.getEducationDetails().getCollegeName());
		callableStatement4.setInt(6, employee.getEducationDetails().getCollegePercent());
		callableStatement4.setInt(7, employee.getEducationDetails().getCollegePassYear());
		callableStatement4.setString(8, employee.getEducationDetails().getEngCourseType());
		callableStatement4.setString(9, employee.getEducationDetails().getEngCollegeName());
		callableStatement4.setInt(10, employee.getEducationDetails().getEngPercent());
		callableStatement4.setInt(11, employee.getEducationDetails().getEngPassYear());
		// callableStatement4.setString(,
		// employee.getEducationDetails().getSchoolName());
		callableStatement4.setString(12, employee.getEducationDetails().getpGCourseType());
		callableStatement4.setString(13, employee.getEducationDetails().getpGCollegeName());
		callableStatement4.setInt(14, employee.getEducationDetails().getpGPercent());
		callableStatement4.setInt(15, employee.getEducationDetails().getpGPassYear());
		int result4 = callableStatement4.executeUpdate();

		CallableStatement callableStatement5 = conn.prepareCall("{call applicationstatus_proc(?,?)}");
		callableStatement5.setString(1, employee.getEmployeeId());
		callableStatement5.setString(2, employee.getReferenceId());
		int result5 = callableStatement5.executeUpdate();

		if (result1 + result2 + result3 + result4 + result5 == 5)
			status = true;
		System.out.println(result1 + " in the userminp");

		conn.commit();

		return status;
	}

}
