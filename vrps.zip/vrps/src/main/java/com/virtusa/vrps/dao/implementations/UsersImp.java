package com.virtusa.vrps.dao.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.vrps.dao.interfaces.UsersDao;
import com.virtusa.vrps.helpers.OracleHelper;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Users;

public class UsersImp implements UsersDao {

	private ResourceBundle rb;
	private Connection conn;
	private Statement statement;
	private ResultSet resultSet;
	private Users users;

	@Override
	public List<Users> getAllUsers() throws SQLException {
		// TODO Auto-generated method stub

		List<Users> userList = new ArrayList<Users>();
		rb = ResourceBundle.getBundle("com/virtusa/vrps/resources/db");
		String getUsersQuery = rb.getString("getUsersQuery");

		conn = OracleHelper.getConnection();
		statement = conn.createStatement();
		resultSet = statement.executeQuery(getUsersQuery);
		// users = new Users();
		while (resultSet.next()) {
			users = new Users();
			users.setUserId(resultSet.getString(1));
			users.setUserPassword(resultSet.getString(2));
			users.setDesignation(resultSet.getString(3));

			userList.add(users);

		}
		conn.close();

		return userList;
	}

	@Override
	public boolean setCreateProfile(Employee employee) throws SQLException {
		// TODO Auto-generated method stub

		conn = OracleHelper.getConnection();
		CallableStatement callableStatement = conn.prepareCall("{call personaldetails(?,?,?,?,?,?,?)}");
		callableStatement.setString(1, employee.getEmployeeId());
		callableStatement.setString(2, employee.getPersonalDetails().getFullName());
		callableStatement.setDate(3, (Date) employee.getPersonalDetails().getDob());
		return false;
	}

}
