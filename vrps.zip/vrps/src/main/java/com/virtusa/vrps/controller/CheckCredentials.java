package com.virtusa.vrps.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.vrps.dao.implementations.UsersImp;
import com.virtusa.vrps.dao.interfaces.UsersDao;
import com.virtusa.vrps.helpers.PasswordHash;
import com.virtusa.vrps.models.Users;

@WebServlet("/CheckCredentials")
public class CheckCredentials extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CheckCredentials() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		UsersDao usersDao = new UsersImp();

		String inpUserId = request.getParameter("userId");
		String inpPassword = request.getParameter("password");
		String inpDesignation = request.getParameter("userType");

		PasswordHash passwordHash = new PasswordHash();
		String hashedpassword = passwordHash.getHash(inpPassword);

		System.out.println(inpUserId + "  " + inpDesignation + "  " + "  " + inpPassword + "  " + hashedpassword);

		try {
			List<Users> userList = usersDao.getAllUsers();

			for (Users users : userList) {

				if (inpUserId.equals(users.getUserId()) && hashedpassword.equals(users.getUserPassword())) {

					request.setAttribute("EmpId", users.getUserId());

					if (users.getDesignation().equalsIgnoreCase("Employee")) {

						RequestDispatcher rs = request.getRequestDispatcher("./views/home.html");
						rs.forward(request, response);
					}

					else {
						request.setAttribute("Designation", users.getDesignation());
						RequestDispatcher rs = request.getRequestDispatcher("./views/home.html");
						rs.forward(request, response);

					}

				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
