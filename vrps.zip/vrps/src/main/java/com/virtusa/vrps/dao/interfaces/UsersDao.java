package com.virtusa.vrps.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.vrps.models.Users;

public interface UsersDao {
	List<Users> getAllUsers() throws SQLException;

}
