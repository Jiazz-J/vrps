package com.virtusa.vrps.models;

public class WorkDetails {

	private String designation;
	private int ctc;
	private String currentLocation;
	private String requiredLocation;
	private int experience;
	private String appliedjob;
	private String skills;

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getCtc() {
		return ctc;
	}

	public void setCtc(int ctc) {
		this.ctc = ctc;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getRequiredLocation() {
		return requiredLocation;
	}

	public void setRequiredLocation(String requiredLocation) {
		this.requiredLocation = requiredLocation;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getAppliedjob() {
		return appliedjob;
	}

	public void setAppliedjob(String appliedjob) {
		this.appliedjob = appliedjob;
	}

}
