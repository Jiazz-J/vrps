
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Insert {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		// TODO Auto-generated method stub

		System.out.println("Press 1 for employee and rest for admin");

		BufferedReader bReader = new BufferedReader(new InputStreamReader(System.in));

		int type = Integer.parseInt(bReader.readLine());

		// int n = sc.nextInt();

		if (type == 1) {
			System.out.println("No of employees");
			int number = Integer.parseInt(bReader.readLine());
			// sc.nextLine();
			while (number-- > 0) {
				System.out.println("      Userid");
				String empid = bReader.readLine();
				// sc.hasNextLine();
				System.out.println("      Password");
				String password = bReader.readLine();
				String enc_password = hash(password);
				String status = "Employee";
				empInsert(empid, enc_password, status);

			}
			System.out.println("Employee data inserted");
		}

		else {
			System.out.println("No of Staff");
			int number = Integer.parseInt(bReader.readLine());

			while (number-- > 0) {
				System.out.println("      userid");
				String empid = bReader.readLine();
				System.out.println("      Password");
				String password = bReader.readLine();
				System.out.println("      Designation AD or TR or HR");
				String desig = bReader.readLine();
				String enc_password = hash(password);
				admInsert(empid, enc_password, desig);

			}
			System.out.println("Admin data inserted");

		}

	}

	static Connection con() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dbUser", "hello");
		return con;
	}

	static String hash(String password) {
		MessageDigest md;
		String enc_pass = null;
		try {
			md = MessageDigest.getInstance("MD5");
			byte[] pass_b = password.getBytes();
			enc_pass = new String(md.digest(pass_b));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return enc_pass;
	}

	private static Connection con;
	private static Statement st;

	static void empInsert(String empid, String password, String status) throws SQLException, ClassNotFoundException {
		con = con();
		st = con.createStatement();
		st.executeUpdate("insert into users values('" + empid + "','" + password + "','" + status + "')");

	}

	static void admInsert(String id, String password, String desig) throws ClassNotFoundException, SQLException {
		con = con();
		st = con.createStatement();
		st.executeUpdate("insert into users values('" + id + "','" + password + "','" + desig + "')");

	}
}
